This is a basic calculator java app for demonstration of CI/CD pipeline using DevOps automation tools.  
Frameworks/Tools used are:  
Maven-Java-Junit  
Eclipse IDE jee - 2019-062  
Git/GitHub  
Jenkins  
RunDeck  
Docker    

To run the app execute: docker run --name "name of container" abhishekacharya/calculator_demo:latest
